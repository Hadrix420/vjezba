package zadaca2;

public class Main {
    public static void main(String[] args) {
        Calculator calc = new Calculator();
        System.out.println(calc.add());
        System.out.println(calc.sub());
    }
}
