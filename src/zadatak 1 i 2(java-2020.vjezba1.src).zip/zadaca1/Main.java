package zadaca1;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Main {
    public static void main(String[] args) {
        PersonChecker personAgeCheckHT25 = new PersonChecker(25, true);
        PersonChecker personAgeCheckLT25 = new PersonChecker(25, false);
        PersonChecker MitarSearch = new PersonChecker("Mitar", false);
        RandomUtilGap gap = new RandomUtilGap();
        PersonDao personDao = new PersonDao();
        List<Person> personList = personDao.getAll();
        for (Person p : personList) {
            System.out.println(p);
        }
        gap.Gap();
        Set<Person> personListNoDupes = new LinkedHashSet<>();
        personListNoDupes.addAll(personList);
        for (Person p : personListNoDupes) {
            System.out.println(p);
        }
        gap.Gap();
        Set<Person> personListSorted = new TreeSet<>();
        personListSorted.addAll(personList);
        for (Person p : personListSorted) {
            System.out.println(p);
        }
        gap.Gap();
        for (Person p : personListSorted) {
            if (personAgeCheckHT25.test(p)) {
                System.out.println(p);
            }
        }
        gap.Gap();
        for (Person p : personListSorted) {
            if (personAgeCheckLT25.test(p)) {
                System.out.println(p);
            }
        }
        gap.Gap();
        for (Person p : personListSorted) {
            if (MitarSearch.test(p)) {
                System.out.println(p);
            }
        }
        gap.Gap();

    }
}
