package zadaca1;

public class RandomUtilGap {
    public void Gap() {
        System.out.println();
        System.out.println("-------------------------------------");
        System.out.println();
    }
}
